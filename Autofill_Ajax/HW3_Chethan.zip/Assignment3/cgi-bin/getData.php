<?php
header ("Content-Type:text/xml");
$url = $_GET["url"];
	

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // output to variable
$response = curl_exec($ch);
curl_close($ch);

echo $response;

?>